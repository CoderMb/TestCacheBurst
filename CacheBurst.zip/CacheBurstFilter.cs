﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CacheBurst
{
    public class CacheBurstFilter:ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            if (!filterContext.ActionParameters.TryGetValue(Global.CacheBurstKey, out var t))
                filterContext.ActionParameters.Add(Global.CacheBurstKey, Global.CacheBurstValue);
            else
                filterContext.ActionParameters[Global.CacheBurstKey] = Global.CacheBurstValue;


           // var nameValues = HttpUtility.ParseQueryString(HttpContext.Current.Request.QueryString.ToString());
           // nameValues.Set(Global.CacheBurstKey, "2.0");
           // string url = HttpContext.Current.Request.Url.AbsolutePath;
           //// RedirectResult(url + "?" + nameValues);

           // //HttpContext.Current.Request.QueryString.Set(Global.CacheBurstKey, "2.0");
           // filterContext.Result = new RedirectResult(url + "?" + nameValues);
            base.OnActionExecuting(filterContext);

            

        }

    }
}