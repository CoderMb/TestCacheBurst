﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CacheBurst
{
    public class Global
    {
        public static readonly string CacheBurstKey = "cb";
        public static readonly string CacheBurstValue = "1.9.0";

    }
}