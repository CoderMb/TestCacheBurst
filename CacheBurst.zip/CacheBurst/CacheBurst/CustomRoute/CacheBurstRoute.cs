﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;

namespace CacheBurst.CustomRoute
{
    public class CacheBurstRoute : System.Web.Routing.Route
    {

        public CacheBurstRoute(string url, IRouteHandler routeHandler) :base(url,routeHandler)
            {

            }
        public CacheBurstRoute(string url, RouteValueDictionary defaults, IRouteHandler routeHandler) : base(url,defaults,routeHandler)
        {

        }
        public CacheBurstRoute(string url, RouteValueDictionary defaults, RouteValueDictionary constraints, IRouteHandler routeHandler) : base(url, defaults, constraints, routeHandler)
        {

        }
        public CacheBurstRoute(string url, RouteValueDictionary defaults, RouteValueDictionary constraints, RouteValueDictionary dataTokens, IRouteHandler routeHandler):base(url,defaults,constraints,dataTokens,routeHandler)
        {

        }





        public override VirtualPathData GetVirtualPath(RequestContext requestContext, RouteValueDictionary values)
        {
            //var preview = System.Web.HttpContext.Current.Session["cb"];

            if (!values.ContainsKey(Global.CacheBurstKey))
                values.Add(Global.CacheBurstKey, Global.CacheBurstValue);

            var path = base.GetVirtualPath(requestContext, values);

            return path;
        }
    }
}